```markdown
# Design System Strategy: Industrial-Futurist Tactical Interface

## 1. Overview & Creative North Star
**Creative North Star: "The Sovereign Commander"**

This design system is engineered to move away from the "neon-soaked" tropes of cyberpunk and the sterile "dashboard" feel of modern SaaS. Instead, it embraces **Industrial Brutalism meets High-End Horology.** The UI should feel like a physical, multi-layered tactical terminal—heavy, expensive, and authoritative. 

The experience is defined by **Intentional Asymmetry** and **Tonal Depth**. By avoiding rigid, centered grids and opting for off-balance layouts with heavy "obsidian" masses balanced by precise "holographic" data points, we create a sense of scale and strategic importance. We don't just display information; we present intelligence.

---

## 2. Colors: The Obsidian Palette
The palette is rooted in deep, non-neutral blacks and cool-toned grays, providing a high-contrast foundation for "holographic" data.

### The "No-Line" Rule
Traditional 1px solid borders are strictly prohibited for sectioning. Structural boundaries are defined through **Background Shift**. To separate a sidebar from a main viewport, transition from `surface` (#10141a) to `surface-container-low` (#181c22). This creates a "milled" look, as if the UI were carved from a single block of graphite.

### Surface Hierarchy & Nesting
Depth is achieved via the Material "Surface Container" tiers:
- **Base Layer:** `surface` (#10141a) – The infinite void of the tactical map.
- **Primary Panels:** `surface-container` (#1c2026) – Standard interface panels.
- **Nested Data:** `surface-container-high` (#262a31) – Individual modules within panels.
- **Active Focus:** `surface-bright` (#353940) – Momentary interaction states.

### The "Glass & Gradient" Rule
Floating tactical overlays must utilize **Glassmorphism**. Use `surface-variant` (#31353c) at 60% opacity with a `20px` backdrop blur. 
*   **Signature Texture:** For primary CTAs, use a linear gradient from `primary` (#f2ca50) to `primary-container` (#d4af37) at a 135-degree angle. This provides a "brushed gold" metallic feel that flat colors cannot replicate.

---

## 3. Typography: Technical Authority
We utilize a dual-font system to balance "High-Tech Command" with "Operational Readability."

*   **Display & Headlines (Space Grotesk):** This is our "Technical Editorial" voice. Use `display-lg` and `headline-md` with generous letter-spacing (0.05em) and uppercase styling for headers to mimic aerospace readouts.
*   **Body & Data (Manrope):** Chosen for its Swiss-style clarity. `body-md` is the workhorse for unit descriptions.
*   **The Data Layer:** Use `label-sm` (Space Grotesk) for all numerical values. This font's geometric apertures make numerical data feel like a live telemetry feed.

---

## 4. Elevation & Depth: Tonal Layering
We reject the standard "drop shadow." In a sci-fi environment, light is emitted from the screen, not a distant sun.

*   **The Layering Principle:** Stacking `surface-container-lowest` (#0a0e14) elements inside `surface-container-high` (#262a31) creates an "inset" or "engraved" look, perfect for inventory slots or data wells.
*   **Ambient Shadows:** For floating modal windows, use a diffused glow rather than a shadow. Use `secondary` (#bdf4ff) at 4% opacity with a `48px` blur. It should feel like a faint holographic hum, not a shadow.
*   **The "Ghost Border" Fallback:** If a containment line is required, use `outline-variant` (#4d4635) at 20% opacity. This creates a "whisper" of an edge that defines space without cluttering the visual field.

---

## 5. Components

### Buttons (Tactical Triggers)
- **Primary:** `primary` (#f2ca50) background, `on-primary` (#3c2f00) text. Sharp corners (`0px`). No border.
- **Secondary (Holographic):** Transparent background, `secondary` (#bdf4ff) text, with a 1px `ghost border` (#bdf4ff at 30% opacity).
- **Tertiary:** `surface-container-highest` (#31353c) background, `on-surface` (#dfe2eb) text. For low-priority utility actions.

### Input Fields (Data Entry)
- **Style:** Background `surface-container-lowest` (#0a0e14). Bottom-only border using `outline` (#99907c) at 40% opacity. 
- **Focus State:** Border shifts to `secondary_container` (#00e3fd) with a subtle `2px` outer glow.

### Cards & Lists (Intelligence Modules)
- **Constraint:** Zero divider lines. 
- **Method:** Group related data using `surface-container-low` (#181c22) as a backing plate. Use 24px of vertical white space to separate distinct modules.
- **Detailing:** Use a `2px` vertical accent of `primary` (#f2ca50) on the far-left edge of a card to denote "Selected" or "Active" status.

### Tactical Tooltips
- **Visuals:** `surface-container-highest` (#31353c) background with a high-contrast `secondary` (#bdf4ff) "label-sm" header. No rounded corners. Use 80% opacity with a heavy backdrop blur.

---

## 6. Do’s and Don’ts

### Do:
*   **Use Intentional Asymmetry:** Align primary navigation to the left, but place global resource stats in the top-right with a different visual weight.
*   **Lean into the "Void":** Use the `background` (#10141a) color to create breathing room. Not every pixel needs a panel.
*   **Embrace Monospaced Numbers:** Ensure all currency and timers use `Space Grotesk` to keep digits from jumping during live updates.

### Don’t:
*   **No Rounded Corners:** `0px` is the absolute rule. Any radius breaks the "Industrial" feel.
*   **No Neon Overload:** Avoid using `secondary` (Cyan) for everything. It is a scalpel, not a paintbrush. Use it only for interactive data or "Holographic" elements.
*   **No Generic Cards:** Never use a white or light-gray card with a drop shadow. It immediately breaks the immersion of the "Coinage" universe.